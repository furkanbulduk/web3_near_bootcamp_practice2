module.exports = require("near-sdk-as/imports");
module.exports.include.push("**/*.unit.spec.ts");
